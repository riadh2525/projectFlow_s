package dz.corepulse.projectflow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectFlowApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectFlowApplication.class, args);
	}

}
